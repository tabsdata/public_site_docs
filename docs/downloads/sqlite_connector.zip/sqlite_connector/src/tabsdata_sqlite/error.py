from tabsdatak.conn.common.error import ConnException, ConnInitException
from tabsdatak.error import ErrorCode, ErrorDef


class SqliteRuntimeException(ConnException):
    """A SQLite read or write failed."""


class SqliteErrorCode(ErrorCode):
    SQLITE_1 = ErrorDef(ConnInitException, "SqliteSrcConn validation failed")
    SQLITE_2 = ErrorDef(ConnInitException, "SqliteDestConn validation failed")
    SQLITE_3 = ErrorDef(ConnInitException, "SqliteSrc validation failed")
    SQLITE_4 = ErrorDef(ConnInitException, "SqliteDest validation failed")
    SQLITE_5 = ErrorDef(SqliteRuntimeException, "SQLite query {index} failed")
    SQLITE_6 = ErrorDef(
        SqliteRuntimeException,
        "SQLite received {slots} table(s) for {tables} target table(s)",
    )
    SQLITE_7 = ErrorDef(SqliteRuntimeException, "SQLite write to {table} failed")
