import sqlite3
from collections.abc import Iterable

import polars as pl

from tabsdatak.spi import (
    DestContext,
    DestDef,
    DestPlugin,
    LazyFrameInput,
    SrcDef,
    SrcPlugin,
    SrcPluginCtx,
    TableFileSpec,
    TableMode,
    to_lazy_frame_inputs,
)
from tabsdata_sqlite import (
    SqliteDest,
    SqliteDestConn,
    SqliteSrc,
    SqliteSrcConn,
    resolve,
)
from tabsdata_sqlite.error import SqliteErrorCode


def connect(conn: SqliteSrcConn | SqliteDestConn) -> sqlite3.Connection:
    return sqlite3.connect(resolve(conn.path))


class SqliteSrcPlugin(SrcPlugin[SqliteSrcConn, SqliteSrc]):
    def read_in(
        self,
        ctx: SrcPluginCtx,
        conn: SqliteSrcConn,
        src: SqliteSrc,
    ) -> list[Iterable[LazyFrameInput]]:
        con = connect(conn)
        try:
            frames = []
            for index, query in enumerate(src.queries):
                try:
                    frame = pl.read_database(query, con)
                except Exception as e:
                    raise SqliteErrorCode.SQLITE_5.exception(cause=e, index=index)
                frames.append([frame.lazy()])
            return to_lazy_frame_inputs(frames)
        finally:
            con.close()


class SqliteDestPlugin(DestPlugin[SqliteDestConn, SqliteDest]):
    def write_out(
        self,
        ctx: DestContext,
        conn: SqliteDestConn,
        dest: SqliteDest,
        tables: list[TableFileSpec],
    ) -> None:
        if len(tables) != len(dest.tables):
            raise SqliteErrorCode.SQLITE_6.exception(
                slots=len(tables), tables=len(dest.tables)
            )

        con = connect(conn)
        try:
            with con:
                con.execute("BEGIN")
                for table, parquet in zip(dest.tables, tables):
                    if parquet is None:
                        continue
                    try:
                        frame = pl.read_parquet(parquet)
                        columns = ", ".join(
                            '"' + c.replace('"', '""') + '"' for c in frame.columns
                        )
                        if dest.if_table_exists == "replace":
                            con.execute(f'DROP TABLE IF EXISTS "{table}"')
                        con.execute(
                            f'CREATE TABLE IF NOT EXISTS "{table}" ({columns})'
                        )
                        marks = ", ".join("?" for _ in frame.columns)
                        con.executemany(
                            f'INSERT INTO "{table}" ({columns}) VALUES ({marks})',
                            frame.iter_rows(),
                        )
                    except Exception as e:
                        raise SqliteErrorCode.SQLITE_7.exception(cause=e, table=table)
        finally:
            con.close()


SQLITE_SRC = SrcDef(
    conn=SqliteSrcConn,
    type_="sqlite-sql-in",
    system="SQLite",
    src_version="v1",
    src=SqliteSrc,
    table_mode=TableMode.SINGLE,
    cardinality=lambda src: len(src.queries),
    plugin=SqliteSrcPlugin,
    explorer=None,
    icon=None,
)

SQLITE_DEST = DestDef(
    conn=SqliteDestConn,
    type_="sqlite-sql-out",
    system="SQLite",
    dest_version="v1",
    dest=SqliteDest,
    cardinality=lambda dest: len(dest.tables),
    plugin=SqliteDestPlugin,
    explorer=None,
    icon=None,
)
